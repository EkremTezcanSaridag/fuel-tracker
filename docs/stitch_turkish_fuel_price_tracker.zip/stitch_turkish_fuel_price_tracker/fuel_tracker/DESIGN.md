---
name: Fuel Tracker
colors:
  surface: '#fbf8ff'
  surface-dim: '#dbd9e1'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f2fb'
  surface-container: '#efecf5'
  surface-container-high: '#eae7ef'
  surface-container-highest: '#e4e1ea'
  on-surface: '#1b1b21'
  on-surface-variant: '#454652'
  inverse-surface: '#303036'
  inverse-on-surface: '#f2eff8'
  outline: '#767683'
  outline-variant: '#c6c5d4'
  surface-tint: '#4c56af'
  primary: '#000666'
  on-primary: '#ffffff'
  primary-container: '#1a237e'
  on-primary-container: '#8690ee'
  inverse-primary: '#bdc2ff'
  secondary: '#9e4200'
  on-secondary: '#ffffff'
  secondary-container: '#fb6d00'
  on-secondary-container: '#562100'
  tertiary: '#380b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#5c1800'
  on-tertiary-container: '#e17c5a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e0e0ff'
  primary-fixed-dim: '#bdc2ff'
  on-primary-fixed: '#000767'
  on-primary-fixed-variant: '#343d96'
  secondary-fixed: '#ffdbcb'
  secondary-fixed-dim: '#ffb691'
  on-secondary-fixed: '#341100'
  on-secondary-fixed-variant: '#793100'
  tertiary-fixed: '#ffdbd0'
  tertiary-fixed-dim: '#ffb59d'
  on-tertiary-fixed: '#390c00'
  on-tertiary-fixed-variant: '#7b2e12'
  background: '#fbf8ff'
  on-background: '#1b1b21'
  surface-variant: '#e4e1ea'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.5px
  price-display:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 16px
  gutter: 12px
---

## Brand & Style
The design system is built for a high-utility Turkish fuel price tracking application. The brand personality is **reliable, efficient, and real-time**, ensuring users can make quick decisions while commuting. 

The aesthetic follows a **Modern Material** approach, evolving standard Material Design principles with cleaner surfaces and more intentional whitespace. It evokes a sense of trust (Deep Blue) and urgency (Orange accents for price changes). The UI is optimized for high-glanceability, particularly in high-glare environments like a car dashboard mount.

## Colors
This design system utilizes a structured palette to indicate hierarchy and data states:

- **Primary (#1A237E):** Used for the App Bar, primary actions, and brand reinforcement. It signifies stability and corporate reliability.
- **Accent/Secondary (#FF6F00):** Reserved for high-priority interactions, active fuel type selections, and highlighting the lowest prices in a list.
- **Semantic Colors:** 
    - **Success (Green):** Indicates a price drop compared to the previous day.
    - **Error (Red):** Indicates a price hike or missing station data.
- **Neutral Palette:** Uses cool greys to maintain a clean, modern look without feeling "muddy."

## Typography
We use **Hanken Grotesk** for its contemporary feel and exceptional legibility in data-heavy views. It offers a cleaner, more sophisticated alternative to standard Roboto while maintaining high performance on Android.

- **Headlines:** Bold and tight for city names and station brands.
- **Price Display:** A specialized weight used for the "TL/L" figures, ensuring the numbers are the first thing a user sees.
- **Labels:** Used for fuel types (Benzin, Motorin, LPG) in all-caps or medium weights to differentiate from body text.

## Layout & Spacing
The layout adheres to a strict **8dp grid system**. 

- **Margins:** 16dp horizontal safe area for all mobile screens.
- **Vertical Rhythm:** Elements are separated by multiples of 8dp (e.g., 16dp between cards, 8dp between a label and its value).
- **Lists:** Station lists use a single-column layout to maximize horizontal space for price comparisons and distance indicators.
- **Touch Targets:** All interactive elements maintain a minimum 48x48dp tap area.

## Elevation & Depth
In line with Modern Material principles, depth is used to communicate hierarchy rather than just decoration:

- **Level 0 (Background):** #F8F9FA, used for the base canvas.
- **Level 1 (Cards):** White background with a subtle shadow (Y: 2, Blur: 4, Opacity: 0.08, Color: #000). Used for station list items.
- **Level 2 (Active/Floating):** Higher elevation shadow (Y: 4, Blur: 8, Opacity: 0.12). Used for the "Filter" FAB (Floating Action Button) and active input states.
- **Navigation:** The Bottom Navigation Bar uses a subtle top-border rather than heavy shadow to keep the interface light.

## Shapes
The design uses a **Rounded (8dp - 12dp)** shape language to feel approachable and modern.

- **Small Components (8dp):** Buttons, Text Inputs, and Chips.
- **Medium Components (12dp):** Cards and Modal Sheets.
- **Full Rounded:** Used specifically for "Price Trend" indicators (pills) and the search bar.

## Components

### Buttons & Chips
- **Primary Button:** Deep Blue background, white text, 8dp corner radius. High emphasis.
- **Fuel Type Chips:** Filter chips at the top of the screen. Unselected: Light grey outline. Selected: Orange background with white text.

### Station Cards
- High-contrast layout. Station logo on the left, Fuel Price in the center-right (Price Display style), and distance/address in Body-md on the bottom. 
- Use a 12dp corner radius and Level 1 elevation.

### Inputs
- **Search Bar:** 24dp (pill-shaped) height, light grey background, trailing "Location" icon.
- **Text Fields:** Outlined style with 8dp radius. Primary color for focus state.

### Specialized Components
- **Price Trend Indicator:** A small pill component next to the price. Green with an "up" arrow for drops (good for user), Red with a "down" arrow for hikes. 
- **City Selector:** A prominent dropdown or modal sheet in the top App Bar for quick geographic switching.